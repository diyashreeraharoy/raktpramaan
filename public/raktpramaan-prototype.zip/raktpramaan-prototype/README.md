# RaktPramaan — Verified Blood Availability. Zero False Hope.

> **Hackathon Benchmark Prototype** | Audit-Ready Decision Engine, Timestamp Freshness Verifier, Idempotent Human Sign-off Gate, and 4 Official Preserved Runs.

---

## 🎯 Executive Summary

In emergency situations, desperate families often traverse multiple hospitals based on outdated portal numbers or false availability claims, only to find zero stock upon arrival. **RaktPramaan** ("Blood Proof") provides a **strictly read-only**, **clinical-grade decision and independent verification system** that:

1. **Protects Portal Targets**: Never submits POST/PUT requests to external portals or blood banks.
2. **Preserves Complete Traceability**: Every request, portal evidence snippet, decision, proposed action, and audit trail carries immutable IDs (`request_id`, `evidence_id`, `decision_id`, `action_id`, `audit_id`).
3. **Audits Timestamps Independently**: Penalizes listings older than 24 hours as `STALE`, isolates missing timestamps as `UNCERTAIN`, and forces a "Call Before Travel" confirmation protocol.
4. **Enforces Human Sign-Off**: Prevents unauthorized automated outreach; enforces one-time authorization with an **idempotency lock** that blocks duplicate retry clicks.
5. **Preserves 4 Official Benchmark Scenarios**: Automatically executes and preserves TC1–TC4 test runs with honest, transparent explanations for deviations.

---

## 🏗️ Architecture & Modules

The prototype is organized into strictly decoupled TypeScript modules with zero external server dependencies:

```
src/
├── types.ts                   # Strict interfaces: BloodRequest, PortalEvidenceRecord, 
│                              # DecisionTrace, CallListItem, ActionApprovalRecord,
│                              # VerificationAuditRecord, OfficialTestRunRecord.
│
├── portalData.ts              # Deterministic test fixtures (TC1-TC4), district adjacency
│                              # graph with road distances, safe read-only HTML table parser.
│
├── decisionEngine.ts          # Deterministic matching rules: group/component matching,
│                              # freshness categorization (>24h stale), distance tie-break,
│                              # call list ranking and dispatch generator.
│
├── actionAndVerification.ts   # Step 4 Human Approval Gate with idempotency retry protection,
│                              # and Step 5 Independent Verification Audit with shortfall calculations.
│
├── testSuiteRunner.ts         # Automated benchmark suite executing TC1–TC4, preserving
│                              # specified inputs, expected results, actual outputs, and honest notes.
│
├── App.tsx                    # Two-tab clinical UI:
│                              #   Tab 1: "Find Blood Stock" (Live emergency clinical workflow)
│                              #   Tab 2: "Verification Audit & Request Log" (Judge matrix & preserved runs)
│
├── main.tsx                   # React 19 application entry point
└── index.css                  # Tailwind CSS styling
```

---

## 🧪 4 Preserved Benchmark Test Cases

| Test Case | Scenario Description | Expected Result | Actual Prototype Result | Audit Explanation |
| :--- | :--- | :--- | :--- | :--- |
| **TC1** | **Darjeeling O- PRBC** | Ranked call list with timestamps | 2 fresh banks ranked (2h & 5h update); 1 bank withheld | Missing timestamp row isolated in Uncertain records rather than guessing freshness. |
| **TC2** | **72-Hour Stale Stock** | Flagged stale & deprioritized | 72h-old bank marked `STALE`, ranked below 3h-old bank | Independent verifier penalizes stale stock despite closer distance (2.5 km vs 8.5 km). |
| **TC3** | **Platelets vs Whole Blood** | Whole Blood not matched | 0 banks matched; 2 Whole Blood rows excluded | Incompatible blood component excluded to prevent dangerous patient trips. |
| **TC4** | **Kalimpong Zero Stock** | Zero local stock + fallback | 0 local units reported; fallback to Darjeeling & Jalpaiguri | Local stockout identified; nearest adjacent district banks offered with travel distance warnings. |

---

## 🔒 Safety & Compliance Guarantees

- **Strictly Read-Only**: Zero write operations against hospital or portal systems.
- **Privacy First**: Uses synthetic/anonymous emergency identifiers with zero real PII stored.
- **Anti-Bypass Compliance**: No OTP or CAPTCHA bypass scripts; includes safe client-side DOM parser for manual HTML table snippet paste.
- **Idempotency Safeguard**: Every human coordinator action has an immutable `idempotency_key`. Subsequent clicks increment `duplicate_retries_blocked` without re-dispatching.

---

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ or 20+
- npm, pnpm, or bun

### Installation
```bash
# Install dependencies
npm install

# Start the local development server
npm run dev
```

Visit `http://localhost:3000` to interact with the prototype.

### Running Checks
```bash
# Type check without emitting files
npm run lint

# Build for production
npm run build
```

---

## 📦 Export & Zip File

The complete codebase is packaged in `public/raktpramaan-prototype.zip`. You can download it directly from the application header or by accessing `/raktpramaan-prototype.zip`.
